function clickLogin() {
    $('#exampleModalCenter').modal('show');
}